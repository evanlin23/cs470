# BridgeFinder midterm — editable Overleaf project

In Overleaf select New Project → Upload Project, then upload this ZIP.
Set the main document to main.tex and the compiler to pdfLaTeX (the defaults
should work). Recompile; references may require a second pass.

Edit main.tex. Its % Rewrite purpose: comments explain what each paragraph
needs to accomplish; they do not appear in the PDF. The section-to-rubric map
is in review/rewrite-guide.md. The bibliography is embedded at the end, so no BibTeX or Biber
step is required. Figures are included at their existing relative paths under
midterm/review/screenshots/. Keep that structure unless you update main.tex.

review/rubric-review.md contains the strict editorial assessment.
review/rewrite-guide.md gives Evan and Eric the final rewrite priorities and
facts that must remain synchronized. These Markdown files do not appear in
the compiled paper. The current draft is four pages; the supplied rubric does
not state a five-page limit. Check the layout after manual edits.

This archive excludes prototype data, code and private study keys. It was
compiled locally after clean extraction using pdfLaTeX. No claim is made
that it has already been uploaded to, or compiled on, the Overleaf service.
