# BridgeFinder midterm — editable Overleaf project

In Overleaf select New Project → Upload Project, then upload this ZIP.
Set the main document to main.tex and the compiler to pdfLaTeX (the defaults
should work). Recompile; references may require a second pass.

Edit main.tex. The bibliography is embedded at the end, so no BibTeX or
Biber step is required. Figures are included at their existing relative paths
under midterm/review/screenshots/. Keep that structure unless you update
main.tex.

review/rubric-review.md scores the report against the midterm rubric.
review/rewrite-guide.md maps sections to the rubric and lists the facts that
must stay synchronized. review/source-checks.md records the sources behind
the related-work comparisons. These Markdown files do not appear in the
compiled paper. The midterm report should stay within 4-5 pages. Check the
layout after manual edits.

This archive excludes prototype data, code and private study keys. It was
compiled locally after clean extraction using pdfLaTeX. No claim is made
that it has already been uploaded to, or compiled on, the Overleaf service.
